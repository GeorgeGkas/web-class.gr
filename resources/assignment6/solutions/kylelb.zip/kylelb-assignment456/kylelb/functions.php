<?php

/*
 * Vidros Socratis 03105180 - Project 5
 */

include 'database.php';

/*
 * ===================================================================================================
 * User space functions
 * ===================================================================================================
 */

//Validates user and appends session variables for this user
function validateUser($user) {
    session_regenerate_id ();
    $_SESSION['userid'] = $user['id'];
    $_SESSION['username'] = $user['username'];
    $_SESSION['valid'] = 1;
}

//Checks if a user is logged in
function isLoggedIn() {
    if ($_SESSION['valid'])
        return true;
    return false;
}

//Log out
function logout() {
    //Destroy all the session variables
    $_SESSION = array();
    session_destroy();
    header("Location: index.php");
}

//Register user
function register($username, $password) {

    if ((isset($username)) && (isset($password))) {

        $selectUsernameQuery = sprintf("SELECT username FROM users WHERE username = '%s'", mysql_real_escape_string($username));
        $selectQueryResult = mysql_query($selectUsernameQuery);

        if (mysql_num_rows($selectQueryResult) == 0) {
            $salt = createSalt();
            $encryptedPassword = sha1($password . $salt);
            $insertQueryResult = mysql_query('INSERT INTO users SET username = "' . $username . '", password = "' . $encryptedPassword . '",salt = "' . $salt . '";');
            header('Location: index.php?reg-succ=Registration was done! Please log in.');
        } else
            header('Location: index.php?reg-err=Username exists');
    } else
        header('Location: index.php?reg-err=Invalid username or password');
}

//Login user
function login($username, $password) {

    if (isset($username) && isset($password)) {

        $loginQuery = sprintf("SELECT * FROM users WHERE username = '%s'", mysql_real_escape_string($username));
        $result = mysql_query($loginQuery);

        //No user found
        if (mysql_num_rows($result) < 1) {
            header('Location: index.php?log-err=No such user exists');
            die();
        }

        //Fetch user
        $user = mysql_fetch_array($result, MYSQL_ASSOC);
        $hash = sha1($password . $user['salt']);

        //Check
        if ($hash != $user['password']) {
            header('Location: index.php?log-err=Username and password mismatch');
            die();
        } else {
            validateUser($user);
        }
        header('Location: index.php');
        die();
    } else {
        header('Location: index.php?log-err=Unspecified username/password');
        die();
    }
}

/*
 * ===================================================================================================
 * File handling functions
 * ===================================================================================================
 */

//Stores file metadata in the database
function storeFileMeta($filename, $filetype, $filesize) {
    if ((isset($filename)) && (isset($filetype)) && (isset($filesize))) {

        $checkUserQuery = sprintf("SELECT id FROM users WHERE username = '%s'", mysql_real_escape_string($_SESSION['username']));
        $checkUserResult = mysql_query($checkUserQuery);

        //No user found
        if (mysql_num_rows($checkUserResult) != 1) {
            //Delete uploaded file
            unlink("uploads/" . $filename);
            header('Location: index.php?file-err=Invalid user');
            die();
        }

        $insertFileMetaQuery = sprintf("INSERT INTO files SET user_id = '%s', name = '%s',type = '%s',size = '%s'", mysql_real_escape_string($_SESSION['userid']), mysql_real_escape_string($filename), mysql_real_escape_string($filetype), mysql_real_escape_string($filesize));
        $insertQueryResult = mysql_query($insertFileMetaQuery);
        if (!$insertQueryResult)
            die('Database error : ' . mysql_error());
    }
}

//Fetch files from the database
function fetchAllFiles() {
    $fetchFilesQuery = "SELECT f.name as filename,u.username,f.size as filesize FROM `files` as f CROSS JOIN users as u on f.user_id = u.id";

    $result = mysql_query($fetchFilesQuery);

    if (!$result)
        die('Database error : ' . mysql_error());

    //Print file table
    echo("<table class=\"file-table\">\n");
    echo("<tr><th>Filename:</th><th>Uploaded by:</th><th>Size:</th></tr>\n");

    while ($row = mysql_fetch_array($result)) {
        //echo("<tr><td><a href=\"preview.php?file=" . $row['filename'] . "\">" . $row['filename'] . "</a></td>");
        //echo("<tr><td><a href=\"javascript:fetchFilePreview('" . $row['filename'] . "')\">" . $row['filename'] . "</a></td>");
        echo("<tr><td><a href='#' title='".$row['filename']."' class='preview'>" . $row['filename'] . "</a></td>");
        echo("<td>");
        echo($row['username']);
        echo("</td>");
        echo("<td>");
        echo(getFilesize($row['filesize']));
        echo("</td>");
        echo("</tr>");
    }
    echo "</table>";
}

//Get file extension
function getFileExtension($filename) {
    $filename = strtolower($filename);
    $exts = split("[/\\.]", $filename);
    $n = count($exts) - 1;
    $exts = $exts[$n];
    return $exts;
}

//Create unique filename - not in use yet
function createUniqueFileName($filename) {
    //Get file extension
    $filename = strtolower($filename);
    $exts = split("[/\\.]", $filename);
    $n = count($exts) - 1;
    $exts = $exts[$n];

    //Special thanks to
    //http://snippets.dzone.com/posts/show/5579
    //Explode the IP of the remote client into four parts
    $ipbits = explode(".", $_SERVER["REMOTE_ADDR"]);

    //Get both seconds and microseconds parts of the time
    list($usec, $sec) = explode(" ", microtime());

    //Fudge the time we just got to create two 16 bit words
    $usec = (integer) ($usec * 65536);
    $sec = ((integer) $sec) & 0xFFFF;

    //Fun bit - convert the remote client's IP into a 32 bit
    //hex number then tag on the time.
    //Result of this operation looks like this xxxxxxxxxxxxxxxx
    $uid = sprintf("%08x%04x%04x", ($ipbits[0] << 24)
                    | ($ipbits[1] << 16)
                    | ($ipbits[2] << 8)
                    | $ipbits[3], $sec, $usec);

    //Tag on the extension and return the filename
    return $uid . "." . $exts;
}

//Gets file size in KB,MB or GB
function getFilesize($bytes) {
    $size = $bytes / 1024;
    if ($size < 1024) {
        $size = number_format($size, 2);
        $size .= ' KB';
    } else {
        if ($size / 1024 < 1024) {
            $size = number_format($size / 1024, 2);
            $size .= ' MB';
        } else if ($size / 1024 / 1024 < 1024) {
            $size = number_format($size / 1024 / 1024, 2);
            $size .= ' GB';
        }
    }
    return $size;
}

//Fetch files from directory
function readDirectory() {

    $directoryName = "uploads/";
    $directory = opendir($directoryName);

    // Get each file from the selected directory
    while (false !== ($file = readdir($directory))) {
        $dirArray[] = $file;
    }

    // Close directory
    closedir($directory);

    // Count elements in the array. We subtract 2 as it also counts . which is current dir and .. which is previous dir
    $indexCount = count($dirArray);
    $filesCount = $indexCount - 2;
    echo("<p style=\"text-align:center;\">There are $filesCount files in $directoryName folder.</p>");

    // Sort the array
    sort($dirArray);

    // Create an html table to list all files
    echo("<table class=\"file-table\">\n");
    echo("<tr><th>Filename</th><th>Filetype</th><th>Filesize</th></tr>\n");
    for ($index = 0; $index < $indexCount; $index++) {
        if (substr("$dirArray[$index]", 0, 1) != ".") { // don't list hidden files
            echo("<tr><td><a href=\"uploads/$dirArray[$index]\">$dirArray[$index]</a></td>");
            echo("<td>");
            echo(filetype($directoryName . $dirArray[$index]));
            echo("</td>");
            echo("<td>");
            echo(filesize($directoryName . $dirArray[$index]));
            echo("</td>");
            echo("</tr>");
        }
    }
    echo("</table>");
}

/*
 * ===================================================================================================
 * Utilities
 * ===================================================================================================
 */

function createSalt() {
    $string = md5(uniqid(rand(), true));
    return substr($string, 0, 3);
}

?>

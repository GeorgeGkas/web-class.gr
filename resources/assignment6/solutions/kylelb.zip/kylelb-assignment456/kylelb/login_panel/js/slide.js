/*
 * Modified by Vidros Socratis 03105180 - Project 5
 */

$(document).ready(function() {

    var panelPos = $.cookie('fb-panel-pos');

    //Check cookie value for panel position
    if (panelPos == 'down') {
        $("div#panel").slideDown("slow");
        $("#toggle a").toggle();
    }
    
    // Expand Panel
    $("#open").click(function(){
        $("div#panel").slideDown("slow");
        $.cookie('fb-panel-pos', 'down', {
            });
    });
	
    // Collapse Panel
    $("#close").click(function(){
        $("div#panel").slideUp("slow");
        $.cookie('fb-panel-pos', 'up', {
            });
    });

    // Switch buttons from "Log In | Register" to "Close Panel" on click
    $("#toggle a").click(function () {
        $("#toggle a").toggle();
    });


    filePreview();
});
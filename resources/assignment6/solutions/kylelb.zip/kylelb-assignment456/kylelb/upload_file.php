<?php

/*
 * Vidros Socratis 03105180 - Project 5
 */

include 'functions.php';

session_start();

$uploadFolder = "uploads/";

//Check file size
if ($_FILES["file"]["size"] < 5000000) {
    if ($_FILES["file"]["error"] > 0) {
        header("Location:index.php?file-err=File error");
        //die("Return Code: " . $_FILES["file"]["error"]);
    } else {
        //Check for dublicate filenames
        if (file_exists($uploadFolder . $_FILES["file"]["name"])) {
            $url = sprintf("Location:index.php?file-err=File '%s' already exists", $_FILES["file"]["name"]);
            header($url);
        } else {
            //createUniqueFileName($_FILES["file"]["name"]);
            //Or simply use timestamp. Keep user friendly filenames for now
            $uniqueFilename = $_SESSION["userid"] . $_FILES["file"]["name"];
            move_uploaded_file($_FILES["file"]["tmp_name"], $uploadFolder . $uniqueFilename);
            storeFileMeta($uniqueFilename, $_FILES["file"]["type"], $_FILES["file"]["size"]);
            header("Location:index.php");
        }
    }
} else {
    header("Location:index.php?file-err=Too large file");
}
?>

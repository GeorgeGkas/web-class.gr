<?php
/*
 * Vidros Socratis 03105180 - Project 5
 */

include 'functions.php';

session_start();

//Log off user
if (isset($_GET['logoff'])) {
    logout();
}
?>

<!DOCTYPE html 
    PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
    <head>
        <title>Funky Box</title>
        <link rel="stylesheet" type="text/css" href="style/style.css"/>
        <!-- Login panel stylesheet -->
        <link rel="stylesheet" type="text/css" href="login_panel/css/slide.css" media="screen" />
        <link rel="icon" type="image/png" href="favicon.ico" />
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="author" content="Vidros Socrates" />
        <meta name="description" content="Funky box is a web-app scripted by Vidros Socrates for the 5th project of the web seminar." />
        <meta name="keywords" content="Web, seminar, vidros, socrates, project" />
        <script type="text/javascript" src="scripts/jquery-1.4.2.min.js"></script>
        <script type="text/javascript" src="scripts/jquery-cookie.js"></script>
        <script type="text/javascript" src="login_panel/js/slide.js" ></script>
        <script type="text/javascript" src="scripts/ajax_file_preview.js"></script>
    </head>
    <body>
        <!-- Top User Panel -->
        <div id="toppanel">
            <div id="panel">
                <div class="content clearfix">
                    <div class="left">
                        <h2>Funky box</h2>
                        <p>This is a web application as part of the Web Seminar fifth project. Users can create an account and drop their files in the box. Everyone can search the box and download files freely.</p>
                        <h3>Special thanks</h3>
                        <p>to <a href="http://web-kreation.com/index.php/tutorials/nice-clean-sliding-login-panel-built-with-jquery" title="Go to site">Web-Kreation</a>'s amazing sliding panel.</p>
                        <p>to <a href="http://www.iconfinder.com" title="Icon finder">IconFinder</a> for the box image.</p>
                    </div>
                    <?php
// Check if a user is logged in
                    if (!isLoggedIn()):
                        //Anonymous user
                    ?>
                        <div class="left">
                            <!-- Login Form -->
                            <form class="clearfix" action="login.php" method="post">
                                <div>
                                    <h2>User Login</h2>

                                <?php
                                // Check for login errors
                                if ($_GET['log-err']) {
                                    echo '<div class="error">' . $_GET['log-err'] . '</div>';
                                    unset($_GET['log-err']);
                                }
                                ?>

                                <label class="grey" for="username">Username:</label>
                                <input class="field" type="text" name="username" id="username2" value="" size="30" />
                                <label class="grey" for="password">Password:</label>
                                <input class="field" type="password" name="password" id="password" size="30" />
                                <div class="clear"></div>
                                <input type="submit" name="submit" value="Login" class="button" />
                            </div>
                        </form>
                    </div>
                    <div class="left right">
                        <!-- Register Form -->
                        <form action="register.php" method="post">
                            <div>
                                <h2>Join Funky Box now!</h2>

                                <?php
                                //Check for registration errrors
                                if ($_GET['reg-err']) {
                                    echo '<div class="error">' . $_GET['reg-err'] . '</div>';
                                    unset($_GET['reg-err']);
                                }

                                //Check for a successfull registration
                                if ($_GET['reg-succ']) {
                                    echo '<div class="success">' . $_GET['reg-succ'] . '</div>';
                                    unset($_GET['reg-succ']);
                                }
                                ?>

                                <label class="grey" for="username">Username:</label>
                                <input class="field" type="text" name="username" id="username" value="" size="30" />
                                <label class="grey" for="password1">Password:</label>
                                <input class="field" type="password" name="password1" id="password1" value="" size="30" />
                                <label class="grey" for="password2">Retype password:</label>
                                <input class="field" type="password" name="password2" id="password2" value="" size="30" />
                                <div class="clear"></div>
                                <input type="submit" name="submit" value="Register" class="button" />
                            </div>
                        </form>
                    </div>

                    <?php
                                // User is logged in
                                else:
                    ?>
                                    <div class="left-large">

                                        <h2>Your panel:</h2>
                                        <p> Welcome <?php echo $_SESSION['username'] ?>! You can now upload your files or <a href="?logoff">Log off</a> and lose the amazing experience of funky box. Its up to you!</p>
                                        <h3>Upload your files</h3>
                                        <div id="file-upload">
                                            <form action="upload_file.php" method="post" enctype="multipart/form-data">
                                                <div>
                                                    Choose file:
                                                    <input class="uploader" type="file" name="file" id="file"></input>
                                                    <div class="clear"></div>
                                                    <input type="submit" name="submit" value="Upload" class="button"/>
                                                </div>
                                            </form>
                                        </div>
                                    </div>

                    <?php
                                    endif;
                    ?>
                                </div>
                            </div>

                            <!-- The tab on top -->
                            <div class="tab">
                                <ul class="login">
                                    <li class="left">&nbsp;</li>
                                    <li>Hello <?php echo $_SESSION['username'] ? $_SESSION['username'] : 'Guest'; ?>!</li>
                                    <li class="sep">|</li>
                                    <li id="toggle">
                                        <a id="open" class="open" href="#"><?php echo $_SESSION['userid'] ? 'Open Panel' : 'Log In | Register'; ?></a>
                                        <a id="close" style="display: none;" class="close" href="#">Close Panel</a>
                                    </li>
                                    <li class="right">&nbsp;</li>
                                </ul>
                            </div>

                        </div>
                        <!-- Main content -->
                        <div id="main-content">
                            <div id="header">
                                <h1>Funky Box</h1>
                <?php
                                    //Check for file errrors
                                    if ($_GET['file-err']) {
                                        echo '<div class="error">' . $_GET['file-err'] . '</div>';
                                        unset($_GET['file-err']);
                                    }
                ?>
                                </div>

                                <p> Browse the box and download any file you wish.</p>
                                <div class="wrapper">

                                    <!-- Show files -->
                <?php fetchAllFiles(); ?>
            </div>
        </div>
        <div class="box"></div>
    </body>
</html>

/*
 * WebSeminar Project 6
 *
 * File preview - Vidros Socrates 03105180
 * 
 * Supported file types: png,gif,jpg,bmp,jpeg,txt
 */

this.filePreview = function(){

    //Constants
    var path = "uploads/";
    var imgRegExp = /\.(jpg|gif|png|bmp|jpeg)(.*)?$/i;
    var textRegExp = /\.(txt)(.*)?$/i;

    //Render loader
    var renderLoader = function(){
        //Check if popup element exists
        if($('#popup').length > 0)
        {
            //Check if loader has already been rendered
            if($('#loader').length == 0)
            {
                $('<div/>').attr('id','loader').css('display','none').appendTo("#popup");
                $('<img/>').attr({
                    'src':'style/images/loader.gif',
                    'alt' : 'Please wait...'
                }).appendTo("#loader");
                $('<p/>').text("Please wait...").appendTo("#loader");
            }
            //Show loader
            $('#loader').show();
        }
        else
            return;
    }

    //Render popup 
    var renderPopup = function(filename){
        //Check if file preview is supported
        if(!(filename.match(textRegExp))&&(!filename.match(imgRegExp)))
        {
            //Preview is not supported so redirect to direct download
            window.location = 'download.php?file=' + filename;
            return;
        }

        //Add background overlay div
        renderOverlay();

        //Check if popup has already been rendered
        if($('#popup').length == 0)
        {
            //Add new popup div
            $('body').append('<div id="popup"></div>');
        
            //Add css styling
            $('#popup').css({
                'display' : 'none',
                'width': $(document).width()/3,
                'height': $(document).height()/3,
                'position' : 'absolute',
                'left' : $(document).width()/3,
                'top': $(document).height()/3,
                'background-color' : '#FFF',
                'border' : '1px solid orange',
                'z-index' : '1000',
                'vertical-align' : 'middle',
                'text-align' : 'center',
                'padding' : '1%',
                'color' : '#444',
                'overflow' : 'auto'
            });
        }
        else
            $('#popup').empty();

        //Show popup
        $('#popup').fadeIn("fast",function(){
            renderLoader();
            renderPreview(filename);
        });
    }

    //Render a gray background overlay
    var renderOverlay = function(){
        if($('#overlay').length == 0)
        {
            $('body').append('<div id="overlay"><div>');
            $('#overlay').css({
                'width':$(document).width(),
                'height': $(document).height(),
                'position' : 'absolute',
                'left' : '0%',
                'top': '0%',
                'background-color' : '#AAA',
                '-moz-opacity': '0.8',
                'opacity':'.80',
                'filter': 'alpha(opacity=80)',
                'z-index' : '1000'
            });
        }
        $('#overlay').show();
    }

    //Render file preview
    var renderPreview = function(filename){
        if(filename.match(textRegExp))
        {
            //Case of a text file - Fetch its data with Ajax
            $.get(path + filename, function(data){
                $('#popup').html("<p><strong>Filename: </strong>" + filename + "</p>" + data);
                addPopupControls( filename );
            });
        }
        else if(filename.match(imgRegExp))
        {
            //Case image file - Create an new image object 
            var imagePreview = new Image();

            //Add image onLoad handler
            imagePreview.onload = function()
            {
                $('#popup').empty();
                
                //Create image tag thumbnail
                var thumbSize = imagePreview.width > imagePreview.height ? imagePreview.width : imagePreview.height
                var popupSize = $('#popup').width() < $('#popup').height() ? $('#popup').width() : $('#popup').height();
                var ratio =  thumbSize <= (0.7 * popupSize) ? 1.0 : ((0.7 * popupSize)/thumbSize);

                $('#popup').append('<p><strong>Filename: </strong>'+ filename +'</p>');

                $('<img/>').attr({
                    'id' : 'imagePreview',
                    'src' : imagePreview.src,
                    'alt' : filename,
                    'width' : imagePreview.width * ratio,
                    'height' : imagePreview.height * ratio
                }).appendTo('#popup');
                addPopupControls( filename );
            }

            //Add image src to start loading
            imagePreview.src = path + filename;
        }
    }

    //Add Popup Controls
    var addPopupControls = function(filename)
    {
        $('#popup').append('<div id="popupControls"><a id="downloadButton" href="download.php?file='+filename +'" title="Download">Download file</a> &nbsp; <a id="closeButton" title="Close preview" href="#">Close</a></div>');
        $('#popupControls').css('padding','10px');

        $('#closeButton').click(function(){
            //Hide popup
            $('#popup').hide();
            $('#overlay').hide();
        })
    }

    //Attach file preview to each file anchor
    $('a.preview').click(function(){
        renderPopup(this.title);
    });
};
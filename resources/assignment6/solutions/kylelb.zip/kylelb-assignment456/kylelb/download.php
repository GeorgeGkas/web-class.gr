<?php

/*
 * Vidros Socratis 03105180 - Project 5
 */

//Force file download
$dir = "uploads/";
if (isset($_GET['file'])) {
    $file = $_GET['file'];
    if (file_exists($dir . $file)) {
        header("Content-type: application/force-download");
        header('Content-Disposition: inline; filename="' . $dir . $file . '"');
        header("Content-Transfer-Encoding: Binary");
        header("Content-length: " . filesize($dir . $file));
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . $file . '"');
        readfile("$dir$file");
    } else {
        die("File not found!");
    }
} else {
    die("No file selected!");
}
?>

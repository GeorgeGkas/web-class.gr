<?php

/*
 * Vidros Socratis 03105180 - Project 5
 */

//Database settings

$dbServer = 'localhost';
$dbPort = '3306';
$dbName = 'assignment6';
$dbUsername = 'root';
$dbPassword = '';

$conn = mysql_connect($dbServer, $dbUsername, $dbPassword);

if (!$conn) {
    die('Could not connect to database: ' . mysql_error());
}

$db_selected = mysql_select_db($dbName, $conn);
if (!$db_selected) {
    die('Database error : ' . mysql_error());
}
?>
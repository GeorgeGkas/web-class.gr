<?php

/*
 * Vidros Socratis 03105180 - Project 5
 */

include 'functions.php';

//Retrieve data from post form
$username = $_POST['username'];
$password1 = $_POST['password1'];
$password2 = $_POST['password2'];

session_start();

//Check if passwords match
if ($password1 != $password2)
    header('Location: index.php?reg-err=Password mismatch error!');
else if (strlen($username) > 30)
    header('Location: index.php?reg-err=Username must me less than 30 characters long');
else
    register($username, $password1);
?>

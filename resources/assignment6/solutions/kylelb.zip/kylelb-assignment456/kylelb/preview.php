<?php

include 'functions.php';
/*
 * Vidros Socratis 03105180 - Project 5
 */

//File preview
$dir = "uploads/";
if (isset($_GET['file'])) {
    $file = $_GET['file'];
    if (file_exists($dir . $file)) {

        $extension = getFileExtension($file);


        if (($extension == 'jpg') || ($extension == 'png') || ($extension == 'gif'))
            header('Content-type: image');
        else if ($extension == 'txt')
            header('Content-type: text');
        else
            die("No available preview. :(");

        header("Content-Transfer-Encoding: Binary");
        header("Content-length: " . filesize($dir . $file));
        header('Content-Type: image');
        //header('Content-Disposition: attachment; filename="' . $file . '"');
        //header('Content-Disposition: inline; filename="' . $dir . $file . '"');
        readfile("$dir$file");
        
    } else {
        die("File not found!");
    }
} else {
    die("No file selected!");
}
?>

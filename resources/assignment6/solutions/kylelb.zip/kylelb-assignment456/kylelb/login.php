<?php

/*
 * Vidros Socratis 03105180 - Project 5
 */

include "functions.php";

session_start();

if ((isset($_POST['username'])) && (isset($_POST['password']))) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    login($username, $password);
} else {
    header('Location: index.php?log-err=Unspecified username/password');
}
?>
#! /usr/bin/python

import cgi
import cgitb; cgitb.enable()
import simplejson

if __name__ == '__main__':
	print "Content-type:text/html"
	print
	form = cgi.FieldStorage()
	keyvals = {}
	for field in form:
		keyvals[field] = form[field].value
	print simplejson.dumps(keyvals)